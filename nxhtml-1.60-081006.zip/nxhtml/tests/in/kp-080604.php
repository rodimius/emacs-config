<?php
require_once dirname(__FILE__) . '/foo.php';
require_once dirname(__FILE__) . '/bar.php';

