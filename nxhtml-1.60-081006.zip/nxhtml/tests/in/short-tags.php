<? $foo=1 ?>, <?= "bla" ?>
        instead of
<?php $foo=1 ?>, <?php echo "bla" ?> 
